package com.improvertech.nativelan

data class NativeLanConfig(
    val projectId: String,
    val sdkKey: String,
    val baseUrl: String = "https://staging-api.nativelan.com",
    val prerelease: Boolean = false,
    val appVersion: String? = null
)
