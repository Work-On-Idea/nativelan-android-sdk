package com.improvertech.nativelan

class OtaResponseEnvelope {
    val success: Boolean = false
    val data: OtaResponseData? = null
}

class OtaResponseData {
    val version: Int = 0
    val delta: Boolean = false
    val localeCode: String = ""
    val strings: Map<String, String>? = null
    val removedKeys: List<String>? = null
}
