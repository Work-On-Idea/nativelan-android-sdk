package com.improvertech.nativelan

import android.content.Context
import android.content.ContextWrapper
import android.content.res.Resources

class NativeLanContextWrapper(base: Context, private val client: NativeLanClient) : ContextWrapper(base) {
    private var customResources: Resources? = null

    override fun getResources(): Resources {
        if (customResources == null) {
            customResources = NativeLanResources(super.getResources(), client)
        }
        return customResources!!
    }
}

class NativeLanResources(
    baseResources: Resources,
    private val client: NativeLanClient
) : Resources(baseResources.assets, baseResources.displayMetrics, baseResources.configuration) {

    override fun getString(id: Int): String {
        return getOtaString(id) ?: super.getString(id)
    }

    override fun getString(id: Int, vararg formatArgs: Any): String {
        return getOtaString(id, *formatArgs) ?: super.getString(id, *formatArgs)
    }

    override fun getText(id: Int): CharSequence {
        return getOtaString(id) ?: super.getText(id)
    }

    override fun getText(id: Int, defaultText: CharSequence): CharSequence {
        return getOtaString(id) ?: super.getText(id, defaultText)
    }

    private fun getOtaString(id: Int, vararg formatArgs: Any): String? {
        return try {
            val key = getResourceEntryName(id)
            client.getTranslation(key, *formatArgs)
        } catch (e: Resources.NotFoundException) {
            null
        }
    }
}
