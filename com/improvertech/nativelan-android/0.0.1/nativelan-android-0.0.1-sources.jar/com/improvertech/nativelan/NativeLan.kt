package com.improvertech.nativelan

import android.content.Context
import android.content.ContextWrapper
import android.util.Log
import androidx.core.os.ConfigurationCompat

interface OtaUpdateListener {
    fun onOtaUpdated()
}

object NativeLan {
    private const val TAG = "NativeLan"
    private var client: NativeLanClient? = null
    private var otaUpdateListener: OtaUpdateListener? = null

    @JvmStatic
    fun setOtaUpdateListener(listener: OtaUpdateListener?) {
        this.otaUpdateListener = listener
    }

    internal fun notifyOtaUpdated() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            otaUpdateListener?.onOtaUpdated()
        }
    }

    @JvmStatic
    fun initialize(
        context: Context,
        projectId: String,
        sdkKey: String,
        baseUrl: String = "http://localhost:3000",
        prerelease: Boolean = false,
        appVersion: String? = null
    ) {
        val config = NativeLanConfig(
            projectId = projectId,
            sdkKey = sdkKey,
            baseUrl = baseUrl,
            prerelease = prerelease,
            appVersion = appVersion
        )
        client = NativeLanClient(context.applicationContext, config)
        
        // Auto fetch initial language mapping matching device locale
        val currentLocale = ConfigurationCompat.getLocales(context.resources.configuration)[0]?.toLanguageTag() ?: "en-US"
        client?.fetchOtaTranslations(currentLocale)
    }

    @JvmStatic
    fun wrap(context: Context): ContextWrapper {
        val activeClient = client
        if (activeClient == null) {
            Log.w(TAG, "NativeLan wrapper called before initialization")
            return ContextWrapper(context)
        }
        return NativeLanContextWrapper(context, activeClient)
    }

    @JvmStatic
    fun setLanguage(locale: String) {
        client?.fetchOtaTranslations(locale)
    }

    @JvmStatic
    fun refresh() {
        val activeClient = client
        if (activeClient != null) {
            activeClient.fetchOtaTranslations(activeClient.getActiveLocale())
        } else {
            Log.w(TAG, "NativeLan refresh called before initialization")
        }
    }

    @JvmStatic
    fun getLanguage(): String {
        return client?.getActiveLocale() ?: "en-US"
    }

    @JvmStatic
    fun t(key: String, vararg formatArgs: Any): String {
        return client?.t(key, *formatArgs) ?: key
    }
}
