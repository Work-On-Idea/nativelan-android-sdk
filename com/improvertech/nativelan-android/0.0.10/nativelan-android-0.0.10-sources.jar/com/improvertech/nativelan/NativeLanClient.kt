package com.improvertech.nativelan

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.core.os.ConfigurationCompat
import com.google.gson.Gson
import okhttp3.*
import okhttp3.HttpUrl.Companion.toHttpUrl
import java.io.IOException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class OtaErrorResponse {
    val success: Boolean = false
    val message: String? = null
    val error: String? = null
}

class NativeLanClient(
    private val context: Context,
    val config: NativeLanConfig
) {
    private val TAG = "NativeLanClient"
    private val PREFS_NAME = "nativelan_prefs"
    private val KEY_STRINGS_PREFIX = "nl_strings_"
    private val KEY_VERSION_PREFIX = "nl_ver_"
    
    private val sharedPrefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val okHttpClient = OkHttpClient()
    private val gson = Gson()
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()

    private var activeLocale: String = "en-US"
    @Volatile
    private var inMemoryStrings = java.util.concurrent.ConcurrentHashMap<String, String>()
    private var currentVersion = 0

    init {
        // Load initial locale from device configuration
        val initialLocale = ConfigurationCompat.getLocales(context.resources.configuration)[0]?.toLanguageTag() ?: "en-US"
        activeLocale = initialLocale
        
        Log.i(TAG, "--------------------------------------------------")
        Log.i(TAG, "🚀 NativeLan SDK Client Initializing...")
        Log.i(TAG, "Project ID: ${config.projectId}")
        
        val keyPreview = if (config.sdkKey.length > 12) {
            config.sdkKey.substring(0, 8) + "..." + config.sdkKey.substring(config.sdkKey.length - 4)
        } else {
            config.sdkKey
        }
        Log.i(TAG, "SDK Key: $keyPreview")
        Log.i(TAG, "Base URL: ${config.baseUrl}")
        Log.i(TAG, "Prerelease Track: ${config.prerelease}")
        Log.i(TAG, "App Version: ${config.appVersion ?: "Not Specified"}")
        Log.i(TAG, "Active Locale: $initialLocale")
        Log.i(TAG, "--------------------------------------------------")
        
        loadFromCache()
        setupLifecycleListener()
    }

    private val activeActivities = java.util.ArrayList<android.app.Activity>()

    private fun setupLifecycleListener() {
        val app = context.applicationContext as? android.app.Application ?: return
        var startedActivities = 0

        app.registerActivityLifecycleCallbacks(object : android.app.Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: android.app.Activity) {
                synchronized(activeActivities) {
                    if (!activeActivities.contains(activity)) {
                        activeActivities.add(activity)
                    }
                }
                if (startedActivities == 0) {
                    Log.i(TAG, "🔄 App entered foreground. Pulling updates from server...")
                    fetchOtaTranslations(activeLocale)
                }
                startedActivities++
            }

            override fun onActivityStopped(activity: android.app.Activity) {
                startedActivities--
                synchronized(activeActivities) {
                    activeActivities.remove(activity)
                }
            }

            override fun onActivityDestroyed(activity: android.app.Activity) {
                synchronized(activeActivities) {
                    activeActivities.remove(activity)
                }
            }

            override fun onActivityCreated(activity: android.app.Activity, savedInstanceState: android.os.Bundle?) {}
            override fun onActivityResumed(activity: android.app.Activity) {}
            override fun onActivityPaused(activity: android.app.Activity) {}
            override fun onActivitySaveInstanceState(activity: android.app.Activity, outState: android.os.Bundle) {}
        })
    }

    fun recreateActiveActivities() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            val targets = synchronized(activeActivities) {
                java.util.ArrayList(activeActivities)
            }
            targets.forEach { activity ->
                if (!activity.isFinishing && !activity.isDestroyed) {
                    activity.recreate()
                }
            }
        }
    }

    fun getActiveLocale(): String {
        return activeLocale
    }

    fun getTranslation(key: String, vararg formatArgs: Any): String? {
        val value = inMemoryStrings[key] ?: return null
        if (formatArgs.isEmpty()) {
            return value
        }
        return try {
            String.format(value, *formatArgs)
        } catch (e: Exception) {
            Log.e(TAG, "Format failure for key '$key' with value '$value': ${e.message}")
            value
        }
    }

    fun t(key: String, vararg formatArgs: Any): String {
        return getTranslation(key, *formatArgs) ?: key
    }

    fun fetchOtaTranslations(locale: String) {
        val normalizedLocale = locale.replace('_', '-')
        if (normalizedLocale != activeLocale) {
            val oldLocale = activeLocale
            activeLocale = normalizedLocale
            Log.i(TAG, "🔄 Active locale changed: [$oldLocale] ➔ [$normalizedLocale]. Reloading local cache...")
            loadFromCache()
        }

        executor.execute {
            try {
                val urlBuilder = "${config.baseUrl}/api/v1/sdk/ota/updates".toHttpUrl().newBuilder()
                urlBuilder.addQueryParameter("locale", normalizedLocale)
                urlBuilder.addQueryParameter("transVersion", currentVersion.toString())
                urlBuilder.addQueryParameter("platform", "android")
                if (config.prerelease) {
                    urlBuilder.addQueryParameter("prerelease", "true")
                }
                config.appVersion?.let {
                    urlBuilder.addQueryParameter("appVersion", it)
                }

                val requestUrl = urlBuilder.build()
                Log.d(TAG, "📡 Fetching updates from: $requestUrl")

                val request = Request.Builder()
                    .url(requestUrl)
                    .addHeader("X-SDK-Key", config.sdkKey)
                    .build()

                okHttpClient.newCall(request).enqueue(object : Callback {
                    override fun onFailure(call: Call, e: IOException) {
                        Log.e(TAG, "--------------------------------------------------")
                        Log.e(TAG, "❌ Connection Failure to NativeLan Server")
                        Log.e(TAG, "URL: $requestUrl")
                        Log.e(TAG, "Is the device connected to the internet / offline?")
                        Log.e(TAG, "Error Details: ${e.message}", e)
                        Log.e(TAG, "--------------------------------------------------")
                    }

                    override fun onResponse(call: Call, response: Response) {
                        response.use { resp ->
                            if (resp.code == 204) {
                                Log.i(TAG, "✅ Translations are up to date (Locale: [$activeLocale], Version: $currentVersion)")
                                return
                            }

                            if (!resp.isSuccessful) {
                                val errorBody = resp.body?.string()
                                var serverMsg: String? = null
                                var errorCode: String? = null
                                if (!errorBody.isNullOrEmpty()) {
                                    try {
                                        val errorObj = gson.fromJson(errorBody, OtaErrorResponse::class.java)
                                        serverMsg = errorObj.message
                                        errorCode = errorObj.error
                                    } catch (parseEx: Exception) {
                                        // ignore
                                    }
                                }
                                Log.e(TAG, "--------------------------------------------------")
                                Log.e(TAG, "❌ NativeLan Server Sync Failed!")
                                Log.e(TAG, "HTTP Status: ${resp.code}")
                                Log.e(TAG, "Error Code: ${errorCode ?: "UNKNOWN"}")
                                Log.e(TAG, "Message: ${serverMsg ?: errorBody ?: "No details provided"}")
                                Log.e(TAG, "Action Required: Check your project ID, credentials, and published bundles.")
                                Log.e(TAG, "--------------------------------------------------")
                                return
                            }

                            val bodyString = resp.body?.string() ?: return
                            try {
                                val envelope = gson.fromJson(bodyString, OtaResponseEnvelope::class.java)
                                if (envelope.success && envelope.data != null) {
                                    applyOtaUpdate(envelope.data)
                                } else {
                                    Log.e(TAG, "⚠️ Received invalid envelope schema from server: $bodyString")
                                }
                            } catch (e: Exception) {
                                Log.e(TAG, "⚠️ Error parsing NativeLan response payload: ${e.message}")
                                Log.d(TAG, "Raw payload: $bodyString")
                            }
                        }
                    }
                })
            } catch (e: Exception) {
                Log.e(TAG, "⚠️ Invalid base URL or parameter initialization failed: ${e.message}")
            }
        }
    }

    private fun applyOtaUpdate(data: OtaResponseData) {
        var versionChanged = false
        synchronized(this) {
            val previousVersion = currentVersion
            val newStrings = java.util.concurrent.ConcurrentHashMap(inMemoryStrings)
            if (data.delta) {
                // Merge updates
                val addedKeys = data.strings?.size ?: 0
                val removedKeys = data.removedKeys?.size ?: 0
                
                data.strings?.let { newStrings.putAll(it) }
                data.removedKeys?.forEach { key ->
                    newStrings.remove(key)
                }
                Log.i(TAG, "✅ Received delta update: Version $previousVersion ➔ ${data.version} (Added: $addedKeys keys, Removed: $removedKeys keys)")
            } else {
                // Full reload
                newStrings.clear()
                data.strings?.let { newStrings.putAll(it) }
                Log.i(TAG, "✅ Received full update: Version $previousVersion ➔ ${data.version} (Total: ${newStrings.size} keys)")
            }
            inMemoryStrings = newStrings
            currentVersion = data.version
            saveToCache()
            if (previousVersion != currentVersion) {
                versionChanged = true
            }
        }
        NativeLan.notifyOtaUpdated()
        if (versionChanged) {
            recreateActiveActivities()
        }
    }

    private fun loadFromCache() {
        val cachedJson = sharedPrefs.getString("$KEY_STRINGS_PREFIX$activeLocale", null)
        currentVersion = sharedPrefs.getInt("$KEY_VERSION_PREFIX$activeLocale", 0)

        val newStrings = java.util.concurrent.ConcurrentHashMap<String, String>()
        if (cachedJson != null) {
            try {
                val map = gson.fromJson(cachedJson, HashMap::class.java)
                map?.forEach { (key, value) ->
                    if (key is String && value is String) {
                        newStrings[key] = value
                    }
                }
                Log.d(TAG, "📦 Loaded ${newStrings.size} translation keys from local cache for [$activeLocale] (version $currentVersion)")
            } catch (e: Exception) {
                Log.e(TAG, "⚠️ Failed to deserialize strings cache for locale [$activeLocale]: ${e.message}")
            }
        } else {
            Log.d(TAG, "ℹ️ No cached strings found for locale [$activeLocale]. Using local xml strings as fallbacks.")
        }
        inMemoryStrings = newStrings
    }

    private fun saveToCache() {
        try {
            val serialized = gson.toJson(inMemoryStrings)
            sharedPrefs.edit()
                .putString("$KEY_STRINGS_PREFIX$activeLocale", serialized)
                .putInt("$KEY_VERSION_PREFIX$activeLocale", currentVersion)
                .apply()
            Log.d(TAG, "💾 Saved ${inMemoryStrings.size} keys to local cache for [$activeLocale] (version $currentVersion)")
        } catch (e: Exception) {
            Log.e(TAG, "⚠️ Failed to write translations to cache: ${e.message}")
        }
    }
}
